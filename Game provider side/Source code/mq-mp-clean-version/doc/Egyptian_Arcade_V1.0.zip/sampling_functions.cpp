#include "stdafx.h"
#include <math.h>
#include "sampling_functions.h"

using namespace std;


int random(unsigned n)
{
	random_device rd;
	mt19937_64 re(rd());
	uniform_int_distribution<int> ui(0, n-1);
	return ui(re);
	//return static_cast<int>( 1.0 * n * rand() / (RAND_MAX + 1.0) );
}

int sample(std::vector<int> x, std::vector<unsigned> weights)
{
	int res = 0;

	//Check x and weights have same length
	if (x.size() == weights.size())
	{
		int acum = 0;
		int length = static_cast<int>(x.size());
		for (int i = 0; i < length; i++) {
			acum += weights[i];
		}
		int r = static_cast<int>(1.0 * acum * rand() / (RAND_MAX + 1.0)); //Int random between 0 and total weight
		int v = 0;
		for (int j = 0; j < length; j++) {
			if (v <= r && r < v + (int)weights[j]) {
				res = x[j];
				break;
			}
			v = v + weights[j];
		}
	}
	else{ printf("Error: x and weights have different lenghts"); }

	return res;
}

int sample_2(std::vector<int> x, std::vector<unsigned> weights, mt19937_64 &re)
{
	//TODO: OLD RNG
	int res = 0;
	/*random_device rd;
	mt19937_64 re(rd());*/
	

	//Check x and weights have same length
	if (x.size() == weights.size())
	{
		int acum = 0;
		int length = static_cast<int>(x.size());
		for (int i = 0; i < length; i++) {
			acum += weights[i];
		}
		uniform_int_distribution<int> ui(0, acum-1);
		//int r = static_cast<int>(1.0 * acum * rand() / (RAND_MAX + 1.0)); //Int random between 0 and total weight
		int r = ui(re);
		int v = 0;
		for (int j = 0; j < length; j++) {
			if (v <= r && r < v + (int)weights[j]) {
				res = x[j];
				break;
			}
			v = v + weights[j];
		}
	}
	else { printf("Error: x and weights have different lenghts"); }

	return res;
}
