#include "stdafx.h"
#include "Environmental_boss.h"
#include <fstream> 
#include <string>

Environmental_boss::Environmental_boss()
{
	load_energy();
	energy = max_energy;
	load_extra_prize_table();
	load_damage_table();
	load_damage_table_low_energy();
	//Set RNG seed
	mt.seed(rd());
}


Environmental_boss::~Environmental_boss()
{
}

unsigned Environmental_boss::award(unsigned total_bet_player)
{

	unsigned extra_prize = 0;
	unsigned damage_prize = 0;
	shots_received++;
	//double random_number = ud01(mt);
	double random_number = ud01(mt);

	//Extra prize
	//First row in table
	if (random_number < cumulative_probs_extra_prize_table[0])
	{
		extra_prize = 1;
	}
	for (int i = 0; i < 3; i++)
	{
		if(random_number < cumulative_probs_extra_prize_table[i+1] && random_number >= cumulative_probs_extra_prize_table[i])
			extra_prize = i + 2;
	}
	
	//Damage prize
	random_number = ud01(mt);
	if (energy > 4)
	{
		//First row in table
		if (random_number < cumulative_probs_damage_table[0] * total_bet_player / total_bet_base_game)
		{
			damage_prize = 1;
			energy -= 1;
		}
		for (int i = 0; i < 4; i++)
		{
			if (random_number < cumulative_probs_damage_table[i + 1] * total_bet_player / total_bet_base_game &&
				random_number >= cumulative_probs_damage_table[i] * total_bet_player / total_bet_base_game)
			{
				damage_prize = i + 2;
				energy -= i + 2;
			}
			
		}

	}
	else
	{
		if (random_number < low_energy_damage_prob * total_bet_player / total_bet_base_game)
		{
			damage_prize = 1;
			energy -= 1;
		}
	}

	//Update state
	if (!energy)
	{
		defeated = true;
		n_defeated++;
	}
		

	return 10 *(extra_prize +  damage_prize); //Stake: 10 credits
}

void Environmental_boss::resets_after_boss_round(void)
{
	defeated = false;
	total_bet_base_game = 0;
	energy = max_energy;
}

int Environmental_boss::get_energy(void)
{
	return energy;
}

void Environmental_boss::load_extra_prize_table()
{
	ifstream file("boss_extra_prize.csv");
	string value;

	for (int i = 0; i < 4; i++)
	{
		getline(file, value, ',');
		cumulative_probs_extra_prize_table.push_back(stod(value));
	}
		
	file.close();
}

void Environmental_boss::load_damage_table()
{
	ifstream file("boss_damage.csv");
	string value;

	for (int i = 0; i < 5; i++)
	{
		getline(file, value, ',');
		cumulative_probs_damage_table.push_back(stod(value));
	}

	file.close();
}

void Environmental_boss::load_damage_table_low_energy()
{
	ifstream file("boss_damage_low_energy.csv");
	string value;

	getline(file, value, ',');
	low_energy_damage_prob = stod(value);


	file.close();
}

void Environmental_boss::load_energy()
{
	ifstream file("boss_energy.csv");
	string value;

	getline(file, value, ',');
	max_energy = stoi(value);

	file.close();

}
