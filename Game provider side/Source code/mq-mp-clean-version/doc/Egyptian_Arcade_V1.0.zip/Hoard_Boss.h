#pragma once
#include <random>

using namespace std;

class Hoard_Boss
{
public:
	Hoard_Boss();
	~Hoard_Boss();

	bool defeated = false;
	unsigned total_bet_base_game = 0;
	unsigned award(unsigned total_bet_player);

	unsigned n_defeated = 0;
	unsigned shots_received = 0;

	void resets_after_boss_round(void);
	int get_energy(void);
private:

	void load_extra_prize_table();
	void load_damage_table();
	void load_damage_table_low_energy();
	double low_energy_damage_prob;
	void load_energy();
	int max_energy;
	int energy;

	//Tables of probabilities
	vector<double> cumulative_probs_extra_prize_table;
	vector<double> cumulative_probs_damage_table;
	//double low_energy_damage_prob;


	//To initialize RNG
	random_device rd;
	//RNG: Mersenne twister 64 bits
	mt19937_64 mt;
	//Uniform distribution in [0,1)
	uniform_real_distribution<double> ud01;
	//Uniform distribution
	uniform_int_distribution<int> ui;
};

