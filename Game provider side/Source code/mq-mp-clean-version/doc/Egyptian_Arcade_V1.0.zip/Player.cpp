#include "stdafx.h"
#include "Player.h"


Player::Player()
{
	//Set RNG seed
	mt.seed(rd());


}


Player::~Player()
{
}

void Player::shoot(Zombie& zombie)
{
	//Gets prize and update zombie state
	//unsigned win = zombie.award_using_weights();
	unsigned win = zombie.award_regular_weapon();
	total_win += win;
	total_base_win += win;
	//
	if (zombie.defeated)
		total_zombies_defeated++;
	total_paid_shots++;
	total_base_game_paid_shots++;
	base_game_shots++;

	//Uniform distribution, Special Weapon. Prob of Special weapon: 1/60
	uniform_int_distribution<int> ui_sw(0, 59);
	//Award a special weapon?
	if (!ui_sw(mt))
	{
		int award_sw =	sample_2(sw, sw_weights, mt);
		switch (award_sw)
		{
		case 0:
			special_weapons_bullets[0] += 3;
			break;
		case 1:
			special_weapons_bullets[1] += 5;
			break;
		case 2:
			special_weapons_bullets[2] += 10;
			break;
		case 3:
			special_weapons_bullets[3] += 1;
			break;
		default:
			break;
		}
	}


}

void Player::shoot_hoard(Zombie_hoard & zombie)
{
	//Gets prize and update zombie state
	//unsigned win = zombie.award_using_weights();
	unsigned win = zombie.award_regular_weapon();
	total_win += win;
	total_base_win += win;
	//
	if (zombie.defeated)
		total_zombies_defeated++;
	total_paid_shots++;
	total_base_game_paid_shots++;
	base_game_shots++;

}

void Player::shoot_special_weapon_1(Zombie &zombie)
{
	//Gets prize and update zombie state
	//unsigned win = zombie.award_using_weights();
	unsigned win = zombie.award_special_weapon_1();
	total_win += win;
	total_base_win += win;
	//
	if (zombie.defeated)
		total_zombies_defeated++;
	//total_paid_shots++;
	//total_base_game_paid_shots++;
	total_shots_sw_1++;
	//base_game_shots++; Shots with special weapon doesn't count for Boss round

	special_weapons_bullets[0]--;
}

void Player::shoot_special_weapon_2(Zombie &zombie)
{
	//Gets prize and update zombie state
	//unsigned win = zombie.award_using_weights();
	unsigned win = zombie.award_special_weapon_2();
	total_win += win;
	total_base_win += win;
	//
	if (zombie.defeated)
		total_zombies_defeated++;
	//total_paid_shots++;
	//total_base_game_paid_shots++;
	total_shots_sw_2++;
	//base_game_shots++; Shots with special weapon doesn't count for Boss round

	special_weapons_bullets[1]--;
}

void Player::shoot_special_weapon_3(Zombie &zombie)
{
	//Gets prize and update zombie state
	//unsigned win = zombie.award_using_weights();
	unsigned win = zombie.award_special_weapon_3();
	total_win += win;
	total_base_win += win;
	//
	if (zombie.defeated)
		total_zombies_defeated++;
	//total_paid_shots++;
	//total_base_game_paid_shots++;
	total_shots_sw_3++;
	//base_game_shots++; Shots with special weapon doesn't count for Boss round

	special_weapons_bullets[2]--;
}
void Player::shoot(Environmental_boss &boss)
{
	if (!boss.defeated)
	{
		//Gets prize and update zombie state
		unsigned win = boss.award(base_game_shots);
		total_win += win;
		total_boss_win += win;
		//

		total_paid_shots++;
		total_boss_shots++;
	}
	else
	{

	}


}

void Player::shoot(Hoard_Boss & boss)
{
	if (!boss.defeated)
	{
		//Gets prize and update zombie state
		unsigned win = boss.award(base_game_shots);
		total_win += win;
		total_boss_win += win;
		//

		total_paid_shots++;
		total_boss_shots++;
	}
	else
	{

	}
}

