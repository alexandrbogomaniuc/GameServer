// Zombie_Arcade.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Zombie.h"
#include "Zombie_hoard.h"
#include "Player.h"
#include "Environmental_boss.h"
#include "Hoard_boss.h"

#define NUMBER_OF_PLAYERS 2
#define NUMBER_OF_ZOMBIES_1_IN_HOARD 10
#define NUMBER_OF_ZOMBIES_2_IN_HOARD 10
#define NUMBER_OF_ZOMBIES_3_IN_HOARD 10

using namespace std;

int main()
{
	//RNG
	random_device rd;
	mt19937_64 mersenne_twister(rd());
	uniform_int_distribution<int> ui(1, 100);
	uniform_int_distribution<int> ui_zh(0, 3); //Zombie hoard prob = 1/4
	uniform_int_distribution<int> ui_players(0, NUMBER_OF_PLAYERS-1);

	//Test: Only 1 Zombie (Zombie is continuosly replaced by another one when defeated)
	Player players[NUMBER_OF_PLAYERS];
	//Shooting rates: Do not use 100 for all players because the first players will shoot more times and the RTP may be biased. 
	int shooting_rate_base_game[NUMBER_OF_PLAYERS]		= { 50,80 };
	int shooting_rate_boss_round[NUMBER_OF_PLAYERS]		= { 80,80 };
	int shooting_rate_hoard[NUMBER_OF_PLAYERS]			= { 80,80 };
	Zombie zombie(2);
	Environmental_boss boss;
	Hoard_Boss hoard_boss;

	for (int i = 0; i < 10000000; i++)
	{
		for (int j = 0; j < NUMBER_OF_PLAYERS; j++)
		{
			if (ui(mersenne_twister) <= shooting_rate_base_game[j])
			{
				//If player has a special weapon then use it
				if (players[j].special_weapons_bullets[0])
				{
					players[j].shoot_special_weapon_1(zombie);
					if (zombie.defeated)
						zombie.resets();
				}
				else
				{
					if (players[j].special_weapons_bullets[1])
					{
						players[j].shoot_special_weapon_2(zombie);
						if (zombie.defeated)
							zombie.resets();
					}
					else
					{
						if (players[j].special_weapons_bullets[2])
						{

							players[j].shoot_special_weapon_3(zombie);
							if (zombie.defeated)
								zombie.resets();
						}
						else
							players[j].shoot(zombie);	//Player shoots at zombie in base game
					}
				}
			}
				



			if (zombie.defeated)
			{
				if (zombie.triggers_boss_round())
				{
					//Update stats
					players[j].boss_rounds_triggered++;
					
					//Play Boss round
					//Total bet
					for (int k = 0; k < NUMBER_OF_PLAYERS; k++)
						boss.total_bet_base_game += players[k].base_game_shots;

					while (!boss.defeated)
					{
						for (int p = 0; p < NUMBER_OF_PLAYERS; p++)
						{
							if (ui(mersenne_twister) <= shooting_rate_boss_round[p] && !boss.defeated)
								players[p].shoot(boss);	//Player shoots at boss
						}

					}


					//Reset base game shots for each player.
					for (int player = 0; player < NUMBER_OF_PLAYERS; player++)
						players[player].base_game_shots = 0;

					//Reset boss
					boss.resets_after_boss_round();

					//Draw if Zombie Hoard is triggered
					if (!ui_zh(mersenne_twister))
					{
						//Count shots by player to distribute the special "hoard prize"
						unsigned shots[NUMBER_OF_PLAYERS];
						unsigned total_number_of_shots = 0;
						//Initialize
						for (int p = 0; p < NUMBER_OF_PLAYERS; p++)
							shots[p] = 0;

						//zombies race 1
						for (int k = 1; k < NUMBER_OF_ZOMBIES_1_IN_HOARD; k++)
						{
							//Hoard of zombies
							Zombie_hoard zombie_hoard(0);
							while(!zombie_hoard.defeated)
							{
								for (int j = 0; j < NUMBER_OF_PLAYERS; j++)
								{
									if (ui(mersenne_twister) <= shooting_rate_hoard[j] && !zombie_hoard.defeated)
									{
										total_number_of_shots++;
										shots[j]++;
										players[j].shoot_hoard(zombie_hoard);
									}

								}
							}
						}
						//zombies race 1
						for (int k = 1; k < NUMBER_OF_ZOMBIES_2_IN_HOARD; k++)
						{
							//Hoard of zombies
							Zombie_hoard zombie_hoard(1);
							while (!zombie_hoard.defeated)
							{
								for (int j = 0; j < NUMBER_OF_PLAYERS; j++)
								{
									if (ui(mersenne_twister) <= shooting_rate_hoard[j] && !zombie_hoard.defeated)
									{
										total_number_of_shots++;
										shots[j]++;
										players[j].shoot_hoard(zombie_hoard);
									}

								}
							}
						}
						//zombies race 3
						for (int k = 1; k < NUMBER_OF_ZOMBIES_3_IN_HOARD; k++)
						{
							//Hoard of zombies
							Zombie_hoard zombie_hoard(2);
							while (!zombie_hoard.defeated)
							{
								for (int j = 0; j < NUMBER_OF_PLAYERS; j++)
								{
									if (ui(mersenne_twister) <= shooting_rate_hoard[j] && !zombie_hoard.defeated)
									{
										total_number_of_shots++;
										shots[j]++;
										players[j].shoot_hoard(zombie_hoard);
									}

								}
							}
						}
					
						//Distribute special hoard prize (x30, stake: 10 credits)
						int special_prize = 300;
						//Choose at random the last player to grant a part of the special prize. 
						int last_player = ui_players(mersenne_twister);
						for (int p = 0; p < NUMBER_OF_PLAYERS ; p++)
						{
							if (p != last_player)
							{
								players[p].total_win += shots[p] / total_number_of_shots * 300; //round down
								special_prize -= shots[p] / total_number_of_shots * 300;
							}

						}
						players[last_player].total_win += special_prize;


						//Play Boss hoard round
						while (!hoard_boss.defeated)
						{
							//players[0].shoot(hoard_boss);	//Player shoots at boss
							for (int p = 0; p < NUMBER_OF_PLAYERS; p++)
							{
								if (ui(mersenne_twister) <= shooting_rate_boss_round[p] && !hoard_boss.defeated)
									players[p].shoot(hoard_boss);	//Player shoots at boss
							}

						}
						//Reset boss
						hoard_boss.resets_after_boss_round();

					}
					

				}
				zombie.resets();
			}
		}
		
	}
		
	unsigned total_players_win = 0;
	unsigned total_players_shots = 0;
	//Players RTPs:
	for (int k = 0; k < NUMBER_OF_PLAYERS; k++)
	{
		printf("Player: %d\n", k);
		printf("Total paid shots: %d\n", players[k].total_paid_shots);
		printf("Base game paid shots: %d\n", players[k].total_base_game_paid_shots);
		printf("Zombies defeated: %d\n", players[k].total_zombies_defeated);
		printf("Avg shot to defeat zoombie: %f\n", 1.0 * players[k].total_base_game_paid_shots / players[k].total_zombies_defeated);
		printf("Boss rounds triggered: %d\n", players[k].boss_rounds_triggered);
		printf("RTP: %f\n\n", 1.0 * players[k].total_win /(10 * players[k].total_paid_shots)); //The cost of each shot is 10 credits
		total_players_win += players[k].total_win;
		total_players_shots += players[k].total_paid_shots;
	}

	//Total RTP
	printf("Total RTP: %f\n", 1.0 * total_players_win / (10 * total_players_shots)) ;//The cost of each shot is 10 credits
	printf("Avg shot to defeat zoombie: %f\n\n\n", 1.0 * zombie.shots_received_rw / zombie.n_defeated);
	printf("Avg shot to defeat boss: %f\n\n\n", 1.0 * boss.shots_received / boss.n_defeated);
	system("PAUSE");
    return 0;
}

