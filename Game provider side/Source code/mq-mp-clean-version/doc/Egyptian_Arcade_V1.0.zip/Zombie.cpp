#include "stdafx.h"
#include "Zombie.h"
#include <fstream> 
#include <string>

Zombie::Zombie(int race)
{
	//Set RNG seed
	mt.seed(rd());

	//Load values for this zombie race.
	load_prizes(race);
	load_probabilities_regular_weapon(race);
	load_probabilities_special_weapon_1(race);
	load_probabilities_special_weapon_2(race);
	load_probabilities_special_weapon_3(race);
	load_boss_probabilities(race);
	boss_round_probability = boss_round_probabilities[0];
}


Zombie::~Zombie()
{
}


void Zombie::resets(void)
{
		right_arm = true;
		left_arm = true;
		head_gear = true;
		defeated = false;
		using_table = 0;
		boss_round_probability = boss_round_probabilities[0];
}

void Zombie::load_prizes(int race)
{
	//Read .csv file
	ifstream file("prizes.csv");

	if (race == 0)
	{
		string value;
		getline(file, value, ',');
		award_left_arm = stoi(value);
		getline(file, value, ',');
		award_right_arm = stoi(value);
		getline(file, value, ',');
		award_head = stoi(value);
	}
	if (race == 1)
	{
		string value;
		getline(file, value,'\n');
		getline(file, value, ',');
		award_left_arm = stoi(value);
		getline(file, value, ',');
		award_right_arm = stoi(value);
		getline(file, value, ',');
		award_head = stoi(value);
	}
	if (race == 2)
	{
		string value;
		getline(file, value, '\n');
		getline(file, value, '\n');
		getline(file, value, ',');
		award_left_arm = stoi(value);
		getline(file, value, ',');
		award_right_arm = stoi(value);
		getline(file, value, ',');
		award_head = stoi(value);
	}


	file.close();

}

void Zombie::load_probabilities_regular_weapon(int race)
{
	if (race == 0)
	{
		//Read .csv file
		ifstream file("prob_race_1.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_1);
		getline(file, value, '\n'); //Next line
		
	    //Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_2);
		getline(file, value, '\n'); //Next line
		
		//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_3);
		getline(file, value, '\n'); //Next line

		//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_4);
		getline(file, value, '\n'); //Next line

		//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_5);
		getline(file, value, '\n'); //Next line

		//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_6);
		getline(file, value, '\n'); //Next line

		//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}
	if (race == 1)
	{
		//Read .csv file
		ifstream file("prob_race_2.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}
	if (race == 2)
	{
		//Read .csv file
		ifstream file("prob_race_3.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_regular_weapon.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}

}

void Zombie::load_probabilities_special_weapon_1(int race)
{
	if (race == 0)
	{
		//Read .csv file
		ifstream file("SPECIAL_WEAPON_1_prob_race_1.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}
	if (race == 1)
	{
		//Read .csv file
		ifstream file("SPECIAL_WEAPON_1_prob_race_2.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}
	if (race == 2)
	{
		//Read .csv file
		ifstream file("SPECIAL_WEAPON_1_prob_race_3.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_1.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}

}

void Zombie::load_probabilities_special_weapon_2(int race)
{
	if (race == 0)
	{
		//Read .csv file
		ifstream file("SPECIAL_WEAPON_2_prob_race_1.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}
	if (race == 1)
	{
		//Read .csv file
		ifstream file("SPECIAL_WEAPON_2_prob_race_2.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}
	if (race == 2)
	{
		//Read .csv file
		ifstream file("SPECIAL_WEAPON_2_prob_race_3.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_2.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}

}

void Zombie::load_probabilities_special_weapon_3(int race)
{
	if (race == 0)
	{
		//Read .csv file
		ifstream file("SPECIAL_WEAPON_3_prob_race_1.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}
	if (race == 1)
	{
		//Read .csv file
		ifstream file("SPECIAL_WEAPON_3_prob_race_2.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}
	if (race == 2)
	{
		//Read .csv file
		ifstream file("SPECIAL_WEAPON_3_prob_race_3.csv");
		vector<double> table_1;
		vector<double> table_2;
		vector<double> table_3;
		vector<double> table_4;
		vector<double> table_5;
		vector<double> table_6;
		vector<double> table_7;
		string value;
		//Table 1
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			table_1.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_1);
		getline(file, value, '\n'); //Next line

									//Table 2
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_2.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_2);
		getline(file, value, '\n'); //Next line

									//Table 3
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_3.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_3);
		getline(file, value, '\n'); //Next line

									//Table 4
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_4.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_4);
		getline(file, value, '\n'); //Next line

									//Table 5
		for (int i = 0; i < 3; i++)
		{
			getline(file, value, ',');
			table_5.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_5);
		getline(file, value, '\n'); //Next line

									//Table 6
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_6.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_6);
		getline(file, value, '\n'); //Next line

									//Table 7
		for (int i = 0; i < 1; i++)
		{
			getline(file, value, ',');
			table_7.push_back(stod(value));
		}
		cumulative_probs_tables_special_weapon_3.push_back(table_7);
		getline(file, value, '\n'); //Next line



		file.close();

	}

}

void Zombie::load_boss_probabilities(int race)
{
	//Read .csv file


	if (race == 0)
	{
		ifstream file("prob_boss_race_1.csv");
		string value;
		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			boss_round_probabilities.push_back(stod(value));
		}

		file.close();
	}
	if (race == 1)
	{
		ifstream file("prob_boss_race_2.csv");
		string value;

		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			boss_round_probabilities.push_back(stod(value));
		}

		file.close();
	}
	if (race == 2)
	{
		ifstream file("prob_boss_race_3.csv");
		string value;

		for (int i = 0; i < 7; i++)
		{
			getline(file, value, ',');
			boss_round_probabilities.push_back(stod(value));
		}


		file.close();
	}


}

unsigned Zombie::award_regular_weapon(void)
{
	shots_received_rw++;
	double random_number = ud01(mt);

	//Table 1
	if (using_table == 0)
	{
		boss_round_probability = boss_round_probabilities[using_table];
		//First row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][0])
		{
			left_arm = false;
			using_table = 1;
			return (unsigned)award_left_arm;
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][1] && random_number >= cumulative_probs_tables_regular_weapon[using_table][0])
		{
			right_arm = false;
			using_table = 2;
			return (unsigned)award_right_arm;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][2] && random_number >= cumulative_probs_tables_regular_weapon[using_table][1])
		{
			head_gear = false;
			using_table = 4;
			return (unsigned)award_head;
		}
		//Fourth row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][3] && random_number >= cumulative_probs_tables_regular_weapon[using_table][2])
		{
			left_arm = false;
			right_arm = false;
			using_table = 3;
			return (unsigned)(award_left_arm + award_right_arm);
		}
		//Fifth row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][4] && random_number >= cumulative_probs_tables_regular_weapon[using_table][3])
		{
			left_arm = false;
			head_gear = false;
			using_table = 6;
			return (unsigned)(award_left_arm + award_head);
		}
		//Sixth row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][5] && random_number >= cumulative_probs_tables_regular_weapon[using_table][4])
		{
			right_arm = false;
			head_gear = false;
			using_table = 5;
			return (unsigned)(award_right_arm + award_head);
		}
		//Last row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][6] && random_number >= cumulative_probs_tables_regular_weapon[using_table][5])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_right_arm + award_head);
		}

	}

	//Table 2 or 3
	if (using_table == 1 || using_table == 2)
	{
		boss_round_probability = boss_round_probabilities[using_table];
		//First row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][0])
		{
			if (using_table == 1)
				right_arm = false;
			if (using_table == 2)
				left_arm = false;
			using_table = 3;
			return (unsigned)award_left_arm; //Both arms pays the same
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][1] && random_number >= cumulative_probs_tables_regular_weapon[using_table][0])
		{
			head_gear = false;
			if (using_table == 1)
				using_table = 6;
			if (using_table == 2)
				using_table = 5;

			return (unsigned)award_head;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][2] && random_number >= cumulative_probs_tables_regular_weapon[using_table][1])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_head); //Both arms pays the same
		}


	}

	//Table 4
	if (using_table == 3)
	{
		boss_round_probability = boss_round_probabilities[using_table];
		//First row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][0])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_head);
		}


	}

	//Table 5
	if (using_table == 4)
	{
		boss_round_probability = boss_round_probabilities[using_table];
		//First row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][0])
		{
			left_arm = false;
			using_table = 6;
			return (unsigned)award_left_arm;
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][1] && random_number >= cumulative_probs_tables_regular_weapon[using_table][0])
		{
			right_arm = false;
			using_table = 5;

			return (unsigned)award_right_arm;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][2] && random_number >= cumulative_probs_tables_regular_weapon[using_table][1])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_right_arm); //Both arms pays the same
		}


	}

	//Table 6 or 7
	if (using_table == 5 || using_table == 6)
	{
		boss_round_probability = boss_round_probabilities[using_table];
		//First row in table
		if (random_number < cumulative_probs_tables_regular_weapon[using_table][0])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm); //Both arms pays the same
		}


	}


	return 0;
}

unsigned Zombie::award_special_weapon_1(void)
{
	shots_received_sw_1++;
	double random_number = ud01(mt);

	//Table 1
	if (using_table == 0)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][0])
		{
			left_arm = false;
			using_table = 1;
			return (unsigned)award_left_arm;
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][1] && random_number >= cumulative_probs_tables_special_weapon_1[using_table][0])
		{
			right_arm = false;
			using_table = 2;
			return (unsigned)award_right_arm;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][2] && random_number >= cumulative_probs_tables_special_weapon_1[using_table][1])
		{
			head_gear = false;
			using_table = 4;
			return (unsigned)award_head;
		}
		//Fourth row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][3] && random_number >= cumulative_probs_tables_special_weapon_1[using_table][2])
		{
			left_arm = false;
			right_arm = false;
			using_table = 3;
			return (unsigned)(award_left_arm + award_right_arm);
		}
		//Fifth row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][4] && random_number >= cumulative_probs_tables_special_weapon_1[using_table][3])
		{
			left_arm = false;
			head_gear = false;
			using_table = 6;
			return (unsigned)(award_left_arm + award_head);
		}
		//Sixth row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][5] && random_number >= cumulative_probs_tables_special_weapon_1[using_table][4])
		{
			right_arm = false;
			head_gear = false;
			using_table = 5;
			return (unsigned)(award_right_arm + award_head);
		}
		//Last row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][6] && random_number >= cumulative_probs_tables_special_weapon_1[using_table][5])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_right_arm + award_head);
		}

	}

	//Table 2 or 3
	if (using_table == 1 || using_table == 2)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][0])
		{
			if (using_table == 1)
				right_arm = false;
			if (using_table == 2)
				left_arm = false;
			using_table = 3;
			return (unsigned)award_left_arm; //Both arms pays the same
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][1] && random_number >= cumulative_probs_tables_special_weapon_1[using_table][0])
		{
			head_gear = false;
			if (using_table == 1)
				using_table = 6;
			if (using_table == 2)
				using_table = 5;

			return (unsigned)award_head;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][2] && random_number >= cumulative_probs_tables_special_weapon_1[using_table][1])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_head); //Both arms pays the same
		}


	}

	//Table 4
	if (using_table == 3)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][0])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_head);
		}


	}

	//Table 5
	if (using_table == 4)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][0])
		{
			left_arm = false;
			using_table = 6;
			return (unsigned)award_left_arm;
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][1] && random_number >= cumulative_probs_tables_special_weapon_1[using_table][0])
		{
			right_arm = false;
			using_table = 5;

			return (unsigned)award_right_arm;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][2] && random_number >= cumulative_probs_tables_special_weapon_1[using_table][1])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_right_arm); //Both arms pays the same
		}


	}

	//Table 6 or 7
	if (using_table == 5 || using_table == 6)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_1[using_table][0])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm); //Both arms pays the same
		}


	}

	return 0;
}

unsigned Zombie::award_special_weapon_2(void)
{
	shots_received_sw_2++;
	double random_number = ud01(mt);

	//Table 1
	if (using_table == 0)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][0])
		{
			left_arm = false;
			using_table = 1;
			return (unsigned)award_left_arm;
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][1] && random_number >= cumulative_probs_tables_special_weapon_2[using_table][0])
		{
			right_arm = false;
			using_table = 2;
			return (unsigned)award_right_arm;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][2] && random_number >= cumulative_probs_tables_special_weapon_2[using_table][1])
		{
			head_gear = false;
			using_table = 4;
			return (unsigned)award_head;
		}
		//Fourth row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][3] && random_number >= cumulative_probs_tables_special_weapon_2[using_table][2])
		{
			left_arm = false;
			right_arm = false;
			using_table = 3;
			return (unsigned)(award_left_arm + award_right_arm);
		}
		//Fifth row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][4] && random_number >= cumulative_probs_tables_special_weapon_2[using_table][3])
		{
			left_arm = false;
			head_gear = false;
			using_table = 6;
			return (unsigned)(award_left_arm + award_head);
		}
		//Sixth row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][5] && random_number >= cumulative_probs_tables_special_weapon_2[using_table][4])
		{
			right_arm = false;
			head_gear = false;
			using_table = 5;
			return (unsigned)(award_right_arm + award_head);
		}
		//Last row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][6] && random_number >= cumulative_probs_tables_special_weapon_2[using_table][5])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_right_arm + award_head);
		}

	}

	//Table 2 or 3
	if (using_table == 1 || using_table == 2)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][0])
		{
			if (using_table == 1)
				right_arm = false;
			if (using_table == 2)
				left_arm = false;
			using_table = 3;
			return (unsigned)award_left_arm; //Both arms pays the same
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][1] && random_number >= cumulative_probs_tables_special_weapon_2[using_table][0])
		{
			head_gear = false;
			if (using_table == 1)
				using_table = 6;
			if (using_table == 2)
				using_table = 5;

			return (unsigned)award_head;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][2] && random_number >= cumulative_probs_tables_special_weapon_2[using_table][1])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_head); //Both arms pays the same
		}


	}

	//Table 4
	if (using_table == 3)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][0])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_head);
		}


	}

	//Table 5
	if (using_table == 4)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][0])
		{
			left_arm = false;
			using_table = 6;
			return (unsigned)award_left_arm;
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][1] && random_number >= cumulative_probs_tables_special_weapon_2[using_table][0])
		{
			right_arm = false;
			using_table = 5;

			return (unsigned)award_right_arm;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][2] && random_number >= cumulative_probs_tables_special_weapon_2[using_table][1])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_right_arm); //Both arms pays the same
		}


	}

	//Table 6 or 7
	if (using_table == 5 || using_table == 6)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_2[using_table][0])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm); //Both arms pays the same
		}


	}

	return 0;
}

unsigned Zombie::award_special_weapon_3(void)
{
	shots_received_sw_3++;
	double random_number = ud01(mt);

	//Table 1
	if (using_table == 0)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][0])
		{
			left_arm = false;
			using_table = 1;
			return (unsigned)award_left_arm;
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][1] && random_number >= cumulative_probs_tables_special_weapon_3[using_table][0])
		{
			right_arm = false;
			using_table = 2;
			return (unsigned)award_right_arm;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][2] && random_number >= cumulative_probs_tables_special_weapon_3[using_table][1])
		{
			head_gear = false;
			using_table = 4;
			return (unsigned)award_head;
		}
		//Fourth row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][3] && random_number >= cumulative_probs_tables_special_weapon_3[using_table][2])
		{
			left_arm = false;
			right_arm = false;
			using_table = 3;
			return (unsigned)(award_left_arm + award_right_arm);
		}
		//Fifth row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][4] && random_number >= cumulative_probs_tables_special_weapon_3[using_table][3])
		{
			left_arm = false;
			head_gear = false;
			using_table = 6;
			return (unsigned)(award_left_arm + award_head);
		}
		//Sixth row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][5] && random_number >= cumulative_probs_tables_special_weapon_3[using_table][4])
		{
			right_arm = false;
			head_gear = false;
			using_table = 5;
			return (unsigned)(award_right_arm + award_head);
		}
		//Last row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][6] && random_number >= cumulative_probs_tables_special_weapon_3[using_table][5])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_right_arm + award_head);
		}

	}

	//Table 2 or 3
	if (using_table == 1 || using_table == 2)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][0])
		{
			if (using_table == 1)
				right_arm = false;
			if (using_table == 2)
				left_arm = false;
			using_table = 3;
			return (unsigned)award_left_arm; //Both arms pays the same
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][1] && random_number >= cumulative_probs_tables_special_weapon_3[using_table][0])
		{
			head_gear = false;
			if (using_table == 1)
				using_table = 6;
			if (using_table == 2)
				using_table = 5;

			return (unsigned)award_head;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][2] && random_number >= cumulative_probs_tables_special_weapon_3[using_table][1])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_head); //Both arms pays the same
		}


	}

	//Table 4
	if (using_table == 3)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][0])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_head);
		}


	}

	//Table 5
	if (using_table == 4)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][0])
		{
			left_arm = false;
			using_table = 6;
			return (unsigned)award_left_arm;
		}
		//Second row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][1] && random_number >= cumulative_probs_tables_special_weapon_3[using_table][0])
		{
			right_arm = false;
			using_table = 5;

			return (unsigned)award_right_arm;
		}
		//Third row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][2] && random_number >= cumulative_probs_tables_special_weapon_3[using_table][1])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm + award_right_arm); //Both arms pays the same
		}


	}

	//Table 6 or 7
	if (using_table == 5 || using_table == 6)
	{
		//First row in table
		if (random_number < cumulative_probs_tables_special_weapon_3[using_table][0])
		{
			//Zombie defeated
			defeated = true;
			n_defeated++;
			//TODO: Update values?
			return (unsigned)(award_left_arm); //Both arms pays the same
		}


	}

	return 0;
}


bool Zombie::triggers_boss_round(void)
{
	if (ud01(mt) < boss_round_probability)
		return true;
	else
		return false;
}
