#pragma once
#include "Zombie.h"
#include "Zombie_hoard.h"
#include "Environmental_boss.h"
#include "Hoard_Boss.h"
#include "sampling_functions.h"


class Player
{
public:
	Player();
	~Player();

	//Player stats
	unsigned total_win = 0;
	unsigned total_base_win = 0;
	unsigned total_boss_win = 0;
	unsigned total_paid_shots = 0;
	unsigned total_base_game_paid_shots = 0;
	unsigned total_boss_shots = 0;
	unsigned total_hoard_shots = 0;

	unsigned total_shots_sw_1 = 0;
	unsigned total_shots_sw_2 = 0;
	unsigned total_shots_sw_3 = 0;

	unsigned main_hits = 0;
	unsigned boss_hits = 0;
	unsigned hoard_hits = 0;

	unsigned total_zombies_defeated = 0;
	unsigned boss_rounds_triggered = 0;
	unsigned boss_rounds_played = 0;

	//Shooting a zombie
	void shoot(Zombie &zombie);
	void shoot_hoard(Zombie_hoard &zombie);
	void shoot_special_weapon_1(Zombie &zombie);
	void shoot_special_weapon_2(Zombie &zombie);
	void shoot_special_weapon_3(Zombie &zombie);

	void shoot(Environmental_boss &boss);
	void shoot(Hoard_Boss &boss);

	//Extra weapon
	unsigned special_weapons_bullets[4] = { 0,0,0,0 }; //Special weapons 1, 2, 3 and Guarantee knockout
	vector<int> sw = { 0,1,2,3 };
	vector<unsigned> sw_weights = { 330,180,309,0 };

	bool guarantee_knockout = false;

	//Base game shots to set boss round weapon
	unsigned base_game_shots = 0;

	//To initialize RNG
	random_device rd;
	//RNG: Mersenne twister 64 bits
	mt19937_64 mt;

	
};

