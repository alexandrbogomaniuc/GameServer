#pragma once
#include <random>

using namespace std;

class Zombie_hoard
{
public:
	Zombie_hoard(int race);
	~Zombie_hoard();
	int race;
	bool defeated = false;

	//Body parts
	bool left_arm = true;
	bool right_arm = true;
	bool head_gear = true;

	//Resets zombie (to use when zombie is defeated)
	void resets(void);

	//When zombie gets shot draw the damage caused (and prize granted). Update zombie variables.
	unsigned award_regular_weapon(void);

private:
	void load_prizes(int race);
	void load_probabilities_regular_weapon(int race);

	int award_left_arm;
	int award_right_arm;
	int award_head;

	//Tables of probabilities
	vector<vector<double>> cumulative_probs_tables_regular_weapon;

	int using_table = 0;

	//To initialize RNG
	random_device rd;
	//RNG: Mersenne twister 64 bits
	mt19937_64 mt;
	//Uniform distribution in [0,1)
	uniform_real_distribution<double> ud01;


};

