#pragma once
#include "stdafx.h"
#include <random>
using namespace std;

int random(unsigned n);	//Returns a pseudo-random number in the range of 0 to n-1.
int sample(std::vector<int> x, std::vector<unsigned> weights);
int sample_2(std::vector<int> x, std::vector<unsigned> weights, mt19937_64 &re);