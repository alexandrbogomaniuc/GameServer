#pragma once
#include <random>

using namespace std;

class Zombie
{
public:
	Zombie(int race);
	~Zombie();
	int race ;
	bool defeated = false;

	//Body parts
	bool left_arm = true;
	bool right_arm = true;
	bool head_gear = true;

	//When zombie gets shot draw the damage caused (and prize granted). Update zombie variables.
	unsigned award_regular_weapon(void);
	unsigned award_special_weapon_1(void);
	unsigned award_special_weapon_2(void);
	unsigned award_special_weapon_3(void);

	//If zombie is defeated then decide if the boss round is triggered or not
	bool triggers_boss_round(void);

	//Resets zombie (to use when zombie is defeated)
	void resets(void);
	unsigned shots_received_rw = 0; //regular weapon
	unsigned shots_received_sw_1 = 0; //special weapon 1
	unsigned shots_received_sw_2 = 0; //special weapon 2
	unsigned shots_received_sw_3 = 0; //special weapon 3
	unsigned n_defeated = 0;

private:
	void load_prizes(int race);
	void load_probabilities_regular_weapon(int race);
	void load_probabilities_special_weapon_1(int race);
	void load_probabilities_special_weapon_2(int race);
	void load_probabilities_special_weapon_3(int race);
	void load_boss_probabilities(int race);

	int award_left_arm;
	int award_right_arm;
	int award_head;

	//Tables of probabilities
	vector<vector<double>> cumulative_probs_tables_regular_weapon;
	vector<vector<double>> cumulative_probs_tables_special_weapon_1;
	vector<vector<double>> cumulative_probs_tables_special_weapon_2;
	vector<vector<double>> cumulative_probs_tables_special_weapon_3;

	vector<double> boss_round_probabilities;
	double boss_round_probability;
	int using_table = 0;

	//To initialize RNG
	random_device rd;
	//RNG: Mersenne twister 64 bits
	mt19937_64 mt;
	//Uniform distribution in [0,1)
	uniform_real_distribution<double> ud01;



};

